import config
import functions


def cmd(api, message):
    banned = functions.getData('banned_peers')
    if banned is None: banned = []

    if not (message['peer_id'] in banned):
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['invalid']} Беседа не заблокирована."
        )
        return

    banned.remove(message['peer_id'])
    edit = functions.editData('banned_peers', banned)

    if edit:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['success']} Беседа была разблокирована!"
        )
    else:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['error']} Беседу не получилось разблокировать. "
        )

    return
