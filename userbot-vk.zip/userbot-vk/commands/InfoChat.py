import config


def cmd(api, message, event):
    chat = api.messages.getChat(chat_id=event.chat_id)
    ownerNameLastName = api.users.get(user_id=chat['admin_id'])[0]
    # admins = [str(admin) for admin in chat['admin_id']]
    try:
        msg = f"""
            Беседа: {chat['title']}
            Участников: {len(chat['users'])}
            Идентификатор: {chat['id']}
            Создатель: {ownerNameLastName['first_name']} {ownerNameLastName['last_name']}
        """.replace('    ', '')
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{msg}"
        )
    except:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['invalid']} Данная команда работает только в беседах."
        )
