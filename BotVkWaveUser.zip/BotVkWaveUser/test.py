import json
import time
from itertools import groupby
import asyncio 
import os

online = []

with open("test.json", "r", encoding='utf-8') as read_file:
    data = json.load(read_file)
    for i in range(0,100):
        try:
            a = data[i]["tasks"][0]["name"]
            b = data[i]["leason"]["name"]
            q = data[i]["day"]
            print(q)
        except:
            print("")
