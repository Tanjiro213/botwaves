from vkwave.bots import *
from command import (
    social_router,
    system_router,
    delete_router,
    auto_router,
    vip_router
)
from Utils.middleware import Middleware
from rich.console import Console
import json

bot = SimpleLongPollUserBot(tokens='5e8cd590c0361b8146206ecf6d85d74f859a3ba61b2c2f2359a365103fd0da20c792b66ba4addb6287dcc')
console = Console()

bot.add_middleware(Middleware())


console.log(f"[bold green]Загрузка команд..")
bot.dispatcher.add_router(system_router)
console.log(f"[bold red] Системные команды загружены..")
bot.dispatcher.add_router(social_router)
console.log(f"[bold red] Социальные команды загружены..")
bot.dispatcher.add_router(delete_router)
console.log(f"[bold red] Удаления команды загружены..")
bot.dispatcher.add_router(auto_router)
console.log(f"[bold red] Команды авто-ответчика загружены..")
bot.dispatcher.add_router(vip_router)
console.log(f"[bold red] Команды для VIP-Пользователей загружены..")

bot.run_forever()
