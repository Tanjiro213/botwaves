from vkwave.bots import (
    MiddlewareResult,
    BaseMiddleware,
    UserEvent
)

class Middleware(BaseMiddleware):
    async def pre_process_event(self, event: UserEvent) -> MiddlewareResult:
        if event.object is None:
            return MiddlewareResult(False)
        if event.object.object.event_id == 4 or event.object.object.event_id == 7 or event.object.object.event_id == 2 or event.object.object.event_id == 5:
            return MiddlewareResult(True)
        return MiddlewareResult(False)
