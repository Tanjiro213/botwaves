from vkwave.bots.core.types.bot_type import BotType
from vkwave.bots import (
    UserEvent,
    BaseEvent
)


class get:
    async def reply_id(self, event: BaseEvent) -> object:
        if event.bot_type == BotType.USER:
            return event.object.object.message_data.marked_users[0][1][0]

        else:
            print('Посмотри ивент, я не доделал для группы')

    async def text(self, event: BaseEvent) -> object:
        if event.bot_type == BotType.USER:
            return event.object.object.text.lower()

        else:
            return event.object.object.message.text.lower()

    async def peer_id(self, event: UserEvent) -> object:
            return event.object.object.peer_id

    async def msg_id(self, event: UserEvent) -> object:
        return event.object.object.message_id

    async def conver_msg_id(self, event: UserEvent) -> object:
        return event.object.object.conversation_message_id

    async def id(self, event: BaseEvent) -> object:
        if event.bot_type == BotType.USER:
            return event.object.object.message_data.from_id

        else:
            return event.object.object.message.from_id
