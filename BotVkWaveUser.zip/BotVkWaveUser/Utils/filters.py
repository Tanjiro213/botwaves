from vkwave.bots.core.types.bot_type import BotType
from vkwave.bots.core.dispatching.filters.base import (
    BaseFilter,
    FilterResult,
    BaseEvent
)
from jellyfish._jellyfish import levenshtein_distance
from typing import Optional, Tuple, Union, List
from vkwave.types.user_events import EventId
import asyncio
import json

def any_text_to_list_or_tuple(t: "AnyText") -> Union[Tuple[str, ...], List[str]]:
    return (t,) if isinstance(t, str) else t

def is_message_event(event: BaseEvent):
    if event.bot_type is BotType.BOT:
        if event.object.type != MessageEventBot:
            raise InvalidEventError
    elif event.bot_type is BotType.USER:
        if event.object.object.event_id not in MessageEventUser:
            raise InvalidEventError

def get_text(event: BaseEvent) -> Optional[str]:
    is_message_event(event)
    if event.bot_type is BotType.USER:
        if event.object.object.dict().get("text") is None:
            return None
        text = event.object.object.text
    else:
        if event.object.object.dict().get("message") is None:
            return None
        text = event.object.object.message.text
    return text


class Levenshtein(BaseFilter):
    def __init__(
            self,
            text: AnyText,
            mistake: int
    ):
        self.text = any_text_to_list_or_tuple(text)
        self.mistake = mistake

    async def check(self, event: BaseEvent) -> FilterResult:
        text = get_text(event)
        if text is None:
            return FilterResult(False)

        text = text.lower()
        for txt in self.text:
            if levenshtein_distance(txt, text) <= self.mistake:
                return FilterResult(True)

class GroupFilterDialog(BaseFilter):
    def __init__(self, group: bool):
        self.group = group

    async def check(self, event: BaseEvent) -> FilterResult:
        if event.bot_type is BotType.USER:
            if ('-' not in str(event.object.object.peer_id)) and (not self.group):
                return FilterResult(True)


class GroupFilterChat(BaseFilter):
    def __init__(self, group: bool):
        self.group = group

    async def check(self, event: BaseEvent) -> FilterResult:
        if event.bot_type is BotType.USER:
            if ('-' not in str(event.object.object.message_data.from_id)) and (not self.group):
                return FilterResult(True)
