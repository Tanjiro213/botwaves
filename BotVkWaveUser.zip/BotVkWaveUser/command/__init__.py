from .social import social_router
from .system import system_router
from .delete import delete_router
from .auto import auto_router
from .vipfunc import vip_router