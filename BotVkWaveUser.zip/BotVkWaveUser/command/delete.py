from vkwave.types.user_events import EventId
import sqlite3
from bs4 import BeautifulSoup
import requests
from vkwave.bots import (
    DefaultRouter,
    UserEvent,
    FromMeFilter,
    MessageFromConversationTypeFilter,
    TextStartswithFilter,
    TextFilter,
    SimpleLongPollBot,
    ReplyMessageFilter,
    FwdMessagesFilter,
    EventTypeFilter
)
db = sqlite3.connect("base.db")
sql = db.cursor()

to_delete = []

sql.execute("""CREATE TABLE IF NOT EXISTS ignorlist(
   id INT
)""")
db.commit()

global url
url = "https://sovminlnr.ru"

bot = SimpleLongPollBot(tokens='5e8cd590c0361b8146206ecf6d85d74f859a3ba61b2c2f2359a365103fd0da20c792b66ba4addb6287dcc',group_id=200042823)
delete_router = DefaultRouter()

def html(site):
    r = requests.get(site)
    return r.text

def get_html(sites):
    soup = BeautifulSoup(sites,"lxml")
    items = soup.find("div",class_="items-news")
    items_all = soup.find_all("div",class_="items-news-i")

    items_new = []

    for i in items_all:
        text = i.find_all("div",class_="text")
        date = i.find_all("div",class_="date")

        for date_post in date:
            dating = date_post.find_all("span")
            for dat in dating:
                print(".")

        for texting_h3 in text:
            text_h3 = texting_h3.find_all("h3")
            text_p = texting_h3.find_all("p")
            for rs in text_h3:
                print(".")
            for p_text in text_p:
                print(".")
        with open("lnr.txt","a") as lnrs:
            itemed = "---" * 5
            lnrs.write(f"{itemed}\nНазвание:\n{rs.text}\nОписание:{p_text.text}\n")

@delete_router.registrar.with_decorator(
    FromMeFilter(True),
    EventTypeFilter(EventId.MESSAGE_EVENT.value),
    TextFilter(['.add']),
    ReplyMessageFilter()
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id
    print(event.object.object)
    if event.object.object.message_data.from_id == 567731830 or event.object.object.message_data.from_id == "567731830":
        msg_id = event.object.object.message_id
        msg_from_id = event.object.object.message_data.marked_users[0][1][0]
        sql.execute(f"INSERT INTO ignorlist(id) VALUES({msg_from_id})")
        db.commit()
        (await event.api_ctx.messages.edit(peer_id=peer_id,
                                           message=f'[💣] [id{msg_from_id}|Пользователь] Был добавлен в ИГНОР-ЛИСТ.',
                                           message_id=msg_id, keep_forward_messages=1))
    else:
        (await bot.api_context.messages.send(message=f'[❌]Отказано в доступе.[❌]',
                                             peer_id=peer_id,
                                             random_id=0))

@delete_router.registrar.with_decorator(
    TextStartswithFilter(['.add']),
    bot.args_filter(args_count=1),
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id
    print(event.object.object.message_data.from_id)
    print(EventTypeFilter(EventId.MESSAGE_EVENT.value))
    if event.object.object.message_data.from_id == 567731830 or event.object.object.message_data.from_id == "567731830":

        msg_id = event.object.object.message_id
        print(event["args"][0])
        events = event["args"][0]
        sql.execute(f"INSERT INTO ignorlist(id) VALUES({events})")
        db.commit()
        (await event.api_ctx.messages.edit(peer_id=peer_id,
                                           message=f'[💣] [id{events}|Пользователь] Был добавлен в ИГНОР-ЛИСТ.',
                                           message_id=msg_id, keep_forward_messages=1))
    else:
        (await bot.api_context.messages.send(message=f'[❌]Отказано в доступе.[❌]',
                                             peer_id=peer_id,
                                             random_id=0))

@delete_router.registrar.with_decorator(
    TextStartswithFilter(['.remove']),
    ReplyMessageFilter()
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    msg_from_id = event.object.object.message_data.marked_users[0][1][0]
    sql.execute(f"DELETE from ignorlist WHERE id={msg_from_id}")
    db.commit()
    (await event.api_ctx.messages.edit(peer_id=peer_id,
                                       message=f'[💣] [id{msg_from_id}|Пользователь] Был удален из ИГНОР-ЛИСТА.',
                                       message_id=msg_id, keep_forward_messages=1))\

@delete_router.registrar.with_decorator(
    TextStartswithFilter(['.remove']),
    bot.args_filter(args_count=1)
)

async def panos(event:UserEvent):
    events = event["args"][0]
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    sql.execute(f"DELETE from ignorlist WHERE id={events}")
    db.commit()
    (await event.api_ctx.messages.edit(peer_id=peer_id,
                                       message=f'[💣] [id{events}|Пользователь] Был удален из ИГНОР-ЛИСТА.',
                                       message_id=msg_id, keep_forward_messages=1))

@delete_router.registrar.with_decorator(
    MessageFromConversationTypeFilter(from_what = 'from_chat'),
)

async def panes(event:UserEvent):
    db = sqlite3.connect("base.db")
    sql = db.cursor()
    peer_id = event.object.object.peer_id
    sql.execute("SELECT * FROM ignorlist")
    ignor = sql.fetchall()
    ignored = list(ignor)
    for i in range(len(ignored)):
        msgs = (await event.api_ctx.messages.get_history(peer_id=peer_id,
                                                count=50)).response.items
        for msg in msgs:
            if msg.from_id == ignored[i][0]:
                to_delete.append(msg.id)
                print(to_delete)
                try:
                    await event.api_ctx.messages.delete(message_ids=to_delete,
                                                delete_for_all=1)
                except:
                      await event.api_ctx.messages.delete(message_ids=to_delete)
                to_delete.clear()




@delete_router.registrar.with_decorator(

    TextFilter(['.e']),
)

async def panos(event:UserEvent):
    gif = (await event.api_ctx.gifts.get(user_id=483664051,count=5)).response.items
    for i in gif:
       print(i.from_id)

@delete_router.registrar.with_decorator(
    TextFilter(['.ignor'])
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    (await event.api_ctx.messages.edit(peer_id=peer_id,
                                       message=f'Команды игнор листа: \n 1. .add [UID], \n 2. .remove [UID] ',
                                       message_id=msg_id))\



@delete_router.registrar.with_decorator(
    TextStartswithFilter(['num']),
    bot.args_filter(args_count=1),
    ReplyMessageFilter()
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id
    # print(peer_id)s
    # if peer_id == 576167340 or peer_id == "576167340":
    msg_id = event.object.object.message_id

    (await event.api_ctx.messages.edit(peer_id=peer_id,
                                       message="pizda",
                                       message_id=msg_id, keep_forward_messages=1))

@delete_router.registrar.with_decorator(
    FromMeFilter(True),
    TextStartswithFilter(['.novosti'])
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id
    get_html(html(url))
    lnr = open("lnr.txt","r")
    (await bot.api_context.messages.send(message = lnr.read(),
                                         peer_id = peer_id,
                                         random_id = 0))

    open('lnr.txt', 'w').close()
