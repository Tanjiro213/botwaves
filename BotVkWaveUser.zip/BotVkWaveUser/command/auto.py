from vkwave.types.user_events import EventId
from vkwave.bots import (
    DefaultRouter,
    UserEvent,
    FromMeFilter,
    MessageFromConversationTypeFilter,
    TextStartswithFilter,
    TextFilter,
    SimpleLongPollBot,
    ReplyMessageFilter,
    FwdMessagesFilter,
    EventTypeFilter
)
import json
import asyncio
from vkwave.api.methods._error import APIError

bot = SimpleLongPollBot(tokens='5e8cd590c0361b8146206ecf6d85d74f859a3ba61b2c2f2359a365103fd0da20c792b66ba4addb6287dcc',group_id=200042823)
auto_router = DefaultRouter()

@auto_router.registrar.with_decorator(
    TextStartswithFilter(['fuck']),
)

async def panos(event:UserEvent):
    peer_id = event.object.object.peer_id

    (await bot.api_context.messages.send(message = f'Пизда',
                                         peer_id = peer_id,
                                         random_id = 0))
# @auto_router.registrar.with_decorator(
#     TextStartswithFilter(['hello']),
# )
#
# async def panos(event:UserEvent):
#     peer_id = event.object.object.peer_id
#
#     print(event.object.object.text)