from vkwave.types.user_events import EventId
import sqlite3
from vkwave.bots import (
    DefaultRouter,
    UserEvent,
    FromMeFilter,
    MessageFromConversationTypeFilter,
    TextStartswithFilter,
    TextFilter,
    SimpleLongPollBot,
    ReplyMessageFilter,
    FwdMessagesFilter,
    EventTypeFilter
)
import psutil

bot = SimpleLongPollBot(tokens='5e8cd590c0361b8146206ecf6d85d74f859a3ba61b2c2f2359a365103fd0da20c792b66ba4addb6287dcc',group_id=200042823)
vip_router = DefaultRouter()

@vip_router.registrar.with_decorator(
    TextStartswithFilter(['xyi']),
    # MessageFromConversationTypeFilter(from_what='from_chat'),
    EventTypeFilter(EventId.MESSAGE_EVENT.value)
)

async def user_id_from_reply(event: UserEvent):
    memory = (psutil.virtual_memory())
    disk = (psutil.disk_usage('/'))
    number = 1024 * 1024 * 1024

    memory_total = memory.total / number
    memory_available = memory.available / number
    memory_used = memory.used / number

    disk_total = disk.total / number
    disk_available = disk.free / number
    disk_used = disk.used / number

    (await bot.api_context.messages.send(peer_id = event.object.object.peer_id,
                                         message = f'🖥 Сведения о : {memory_total:.3} GB\n      Свободно: {memory_available:.3} GB\n      Используется: {memory_used:.3} GB\n  💿 Нагрузка ЦП: {psutil.cpu_percent()}%\n  💽 Диск:\n      Всего: {disk_total:.4} GB\n      Свободно: {disk_available:.3} GB\n      Используется: {disk_used:.3} GB',
                                         random_id = 0))




