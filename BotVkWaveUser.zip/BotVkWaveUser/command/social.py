from vkwave.types.user_events import EventId
from vkwave.bots import (
    DefaultRouter,
    UserEvent,
    FromMeFilter,
    MessageFromConversationTypeFilter,
    TextStartswithFilter,
    TextFilter,
    SimpleLongPollBot,
    ReplyMessageFilter,
    FwdMessagesFilter,
    EventTypeFilter
)
import json
import asyncio
from vkwave.api.methods._error import APIError
import json
import time 
import requests

bot = SimpleLongPollBot(tokens='5e8cd590c0361b8146206ecf6d85d74f859a3ba61b2c2f2359a365103fd0da20c792b66ba4addb6287dcc',group_id=200042823)
social_router = DefaultRouter()

async def main(): 
    await asyncio.sleep(15) 
    f = open('online.txt', 'w', encoding='utf-8')
    f.write(" ")
    f.close()

@social_router.registrar.with_decorator(
    FromMeFilter(True),
    MessageFromConversationTypeFilter(from_what = 'from_chat'),
    EventTypeFilter(EventId.MESSAGE_EVENT.value),
    TextFilter('+др'),
    ReplyMessageFilter()
)
async def fr_add(event: UserEvent):
    friends_get = (await event.api_ctx.friends.get(user_id = 567731830)).response.items
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    msg_from_id = event.object.object.message_data.marked_users[0][1][0]

    if msg_from_id in friends_get:
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[♻] [id{msg_from_id}|Пользователь] уже находится в друзьях.',
                                           message_id = msg_id,
                                           keep_forward_messages = 1))

    else:
        try:
            (await event.api_ctx.friends.add(user_id = msg_from_id))
            (await event.api_ctx.messages.edit(peer_id = peer_id,
                                               message = f'[♻] [id{msg_from_id}|Пользователь] добавлен в друзья.',
                                               message_id = msg_id,
                                               keep_forward_messages = 1))
        except APIError:
            (await event.api_ctx.messages.edit(peer_id = peer_id,
                                               message = f'[💣] [id{msg_from_id}|Пользователь] находится в черном списке и не может быть добавлен в друзья.',
                                               message_id = msg_id,
                                               keep_forward_messages = 1))
        await asyncio.sleep(5)
        (await event.api_ctx.messages.delete(message_ids = msg_id,
                                             delete_for_all = 1))



@social_router.registrar.with_decorator(
    TextStartswithFilter('+др'),
    bot.args_filter(args_count=1),
)
async def fr_add(event: UserEvent):
    friends_get = (await event.api_ctx.friends.get(user_id = 567731830)).response.items
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    events = event["args"][0]

    if msg_from_id in friends_get:
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[♻] [id{events}|Пользователь] уже находится в друзьях.',
                                           message_id = msg_id,
                                           keep_forward_messages = 1))

    else:
        try:
            (await event.api_ctx.friends.add(user_id = events))
            (await event.api_ctx.messages.edit(peer_id = peer_id,
                                               message = f'[♻] [id{events}|Пользователь] добавлен в друзья.',
                                               message_id = msg_id,
                                               keep_forward_messages = 1))
        except APIError:
            (await event.api_ctx.messages.edit(peer_id = peer_id,
                                               message = f'[💣] [id{events}|Пользователь] находится в черном списке и не может быть добавлен в друзья.',
                                               message_id = msg_id,
                                               keep_forward_messages = 1))
        await asyncio.sleep(5)
        (await event.api_ctx.messages.delete(message_ids = msg_id,
                                             delete_for_all = 1))



@social_router.registrar.with_decorator(
    TextFilter('online'),
)
async def fr_add(event: UserEvent):
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    onlineOld = []
    online = []
    site = 'https://xn--7--6kcajpc3answvrgdm9s.xn----7sb3aecmcv8d.xn--p1ai/api/guest/week-schedule?eclass=9'
    html = requests.get(site)
    htmlLoad = str(html.text)
    data = json.loads(htmlLoad)
    print(data)
    for i in range(0,100):
        try:
            a = data[i]["tasks"][0]["name"]
            b = data[i]["leason"]["name"]
            m = data[i]["day"]
            y = data[i]["time_start"]
            n = data[i]["time_end"]
            c = [a, b, m,y,n]
            d = [c[0], c[1], str(c[2]), str(c[3]), str(c[4])]
            if c[0].find("Онлайн") != -1:
                online.append(d)

        except IndexError:
            print("i am xyi")

    for l in online:
        f = open('online.txt','a',encoding='utf-8')
        f.write("\n" + f'▔▔▔▔▔▔▔▔▔▔▔▔\n Урок: {l[1]}: {l[0]}\n Дата: {l[2]} Апреля\n Начало урока: {l[3]}\n Конец урока: {l[4]} ')

        

    try:
        f = open('online.txt','r',encoding='utf-8')

        (await bot.api_context.messages.send(message=f.read(),
                                            peer_id=peer_id,
                                            random_id=0))
        open('online.txt','w').close()
    except APIError:
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                            message = f'[💣] [id{msg_from_id}|Пользователь] находится в черном списке и не может быть добавлен в друзья.',
                                            message_id = msg_id,
                                            keep_forward_messages = 1))
        




@social_router.registrar.with_decorator(
    FromMeFilter(True),
    MessageFromConversationTypeFilter(from_what = 'from_chat'),
    EventTypeFilter(EventId.MESSAGE_EVENT.value),
    TextFilter('+чс'),
    ReplyMessageFilter()
)


async def block_add(event: UserEvent):
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    msg_from_id = event.object.object.message_data.marked_users[0][1][0]

    try:

        (await event.api_ctx.account.ban(owner_id = msg_from_id))
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[💣] [id{msg_from_id}|Пользователь] добавлен в черный список.',
                                           message_id = msg_id, keep_forward_messages = 1))

    except APIError:
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[💣] [id{msg_from_id}|Пользователь] уже находится в черном списке',
                                           message_id = msg_id, keep_forward_messages = 1))

    await asyncio.sleep(5)
    (await event.api_ctx.messages.delete(message_ids = msg_id, delete_for_all = 1))




@social_router.registrar.with_decorator(
    TextStartswithFilter('+чс'),
    bot.args_filter(args_count=1),
)
async def block_add(event: UserEvent):
    events = event["args"][0]
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id

    try:
        (await event.api_ctx.account.ban(owner_id = events))
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                            message = f'[💣] [id{events}|Пользователь] добавлен в черный список.',
                                            message_id = msg_id, keep_forward_messages = 1))

    except APIError:
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[💣] [id{events}|Пользователь] уже находится в черном списке',
                                           message_id = msg_id, keep_forward_messages = 1))

    await asyncio.sleep(5)
    (await event.api_ctx.messages.delete(message_ids = msg_id, delete_for_all = 1))



@social_router.registrar.with_decorator(
    FromMeFilter(True),
    MessageFromConversationTypeFilter(from_what = 'from_chat'),
    EventTypeFilter(EventId.MESSAGE_EVENT.value),
    TextFilter('-др'),
    ReplyMessageFilter()
)
async def fr_remove(event: UserEvent):
    friends_get = (await event.api_ctx.friends.get(user_id = 567731830)).response.items
    app_get = (await event.api_ctx.friends.get_requests(out = 1)).response.items
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    msg_from_id = event.object.object.message_data.marked_users[0][1][0]

    if (msg_from_id not in friends_get) and (msg_from_id not in app_get):
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[♻] [id{msg_from_id}|Пользователь] не находится в списке друзей.',
                                           message_id = msg_id,
                                           keep_forward_messages = 1))

    else:
        (await event.api_ctx.friends.delete(user_id = msg_from_id))

        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[♻] [id{msg_from_id}|Пользователь] удален из друзей.',
                                           message_id = msg_id,
                                           keep_forward_messages = 1))

    await asyncio.sleep(5)

    (await event.api_ctx.messages.delete(message_ids = msg_id,
                                         delete_for_all = 1))
@social_router.registrar.with_decorator(
    TextStartswithFilter('-др'),
    bot.args_filter(args_count=1),
)
async def fr_remove(event: UserEvent):
    friends_get = (await event.api_ctx.friends.get(user_id = 567731830)).response.items
    app_get = (await event.api_ctx.friends.get_requests(out = 1)).response.items
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    events = event["args"][0]
    if (events not in friends_get) or (events not in app_get):
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[♻] [id{events}|Пользователь] не находится в списке друзей.',
                                           message_id = msg_id,
                                           ))

    else:
        (await event.api_ctx.friends.delete(user_id = events))

        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[♻] [id{events}|Пользователь] удален из друзей.',
                                           message_id = msg_id,
                                           keep_forward_messages = 1))

    await asyncio.sleep(5)

    (await event.api_ctx.messages.delete(message_ids = msg_id,
                                         delete_for_all = 1))


@social_router.registrar.with_decorator(
    FromMeFilter(True),
    MessageFromConversationTypeFilter(from_what = 'from_chat'),
    EventTypeFilter(EventId.MESSAGE_EVENT.value),
    TextFilter('-чс'),
    ReplyMessageFilter()
)
async def block_remove(event: UserEvent):
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    msg_from_id = event.object.object.message_data.marked_users[0][1][0]
    try:

        (await event.api_ctx.account.unban(owner_id = msg_from_id))
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[💣] [id{msg_from_id}|Пользователь] удален из черного списка.',
                                           message_id = msg_id,
                                           keep_forward_messages = 1))

    except APIError:
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[💣] [id{msg_from_id}|Пользователь] не находится в черном списке.',
                                           message_id = msg_id,
                                           keep_forward_messages = 1))

    await asyncio.sleep(5)

    (await event.api_ctx.messages.delete(message_ids = msg_id,
                                         delete_for_all = 1))
@social_router.registrar.with_decorator(
    TextStartswithFilter('-чс'),
    bot.args_filter(args_count=1),

)
async def block_remove(event: UserEvent):
    events = event["args"][0]
    peer_id = event.object.object.peer_id
    msg_id = event.object.object.message_id
    try:

        (await event.api_ctx.account.unban(owner_id = events))
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[💣] [id{events}|Пользователь] удален из черного списка.',
                                           message_id = msg_id,
                                           keep_forward_messages = 1))

    except APIError:
        (await event.api_ctx.messages.edit(peer_id = peer_id,
                                           message = f'[💣] [id{events}|Пользователь] не находится в черном списке.',
                                           message_id = msg_id,
                                           keep_forward_messages = 1))

    await asyncio.sleep(5)

    (await event.api_ctx.messages.delete(message_ids = msg_id,
                                         delete_for_all = 1))


@social_router.registrar.with_decorator(
    FromMeFilter(True),
    MessageFromConversationTypeFilter(from_what = 'from_pm'),
    EventTypeFilter(EventId.MESSAGE_EVENT.value),
    TextFilter('/чс'),
)
async def block_add_ls(event: UserEvent):
    await event.api_ctx.account.ban(owner_id = event.object.object.peer_id)
